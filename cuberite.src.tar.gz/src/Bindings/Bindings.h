/*
** Lua binding: AllToLua
** Generated automatically by tolua++-1.0.92 on Sat Apr 22 13:38:19 2017.
*/

/* Exported function */
TOLUA_API int  tolua_AllToLua_open (lua_State* tolua_S);


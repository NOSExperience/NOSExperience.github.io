
// Globals.cpp

// This file is used for precompiled header generation in MSVC environments

#include "Globals.h"






#pragma once

#include "ItemHandler.h"





class cItemClothHandler :
	public cItemHandler
{
public:
	cItemClothHandler(int a_ItemType)
		: cItemHandler(a_ItemType)
	{

	}
} ;





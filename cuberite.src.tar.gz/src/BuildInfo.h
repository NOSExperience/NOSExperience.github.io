
#pragma once

/* #undef BUILD_ID */

#ifdef BUILD_ID

#undef BUILD_ID

#define BUILD_SERIES_NAME ""
#define BUILD_ID          ""
#define BUILD_COMMIT_ID   ""
#define BUILD_DATETIME    ""
#endif


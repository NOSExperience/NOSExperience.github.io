#pragma once

class cSleep
{
public:
	static void MilliSleep( unsigned int a_MilliSeconds);
};

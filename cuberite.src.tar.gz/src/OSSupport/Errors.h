
#pragma once

AString GetOSErrorString(int a_ErrNo);


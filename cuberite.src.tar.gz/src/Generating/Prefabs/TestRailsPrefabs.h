
// TestRailsPrefabs.h

// Declares the prefabs in the group TestRails

#include "../Prefab.h"





extern const cPrefab::sDef g_TestRailsPrefabs[];
extern const cPrefab::sDef g_TestRailsStartingPrefabs[];
extern const size_t g_TestRailsPrefabsCount;
extern const size_t g_TestRailsStartingPrefabsCount;


// PlainsVillagePrefabs.h

// Declares the prefabs in the group PlainsVillage

#include "../Prefab.h"





extern const cPrefab::sDef g_PlainsVillagePrefabs[];
extern const cPrefab::sDef g_PlainsVillageStartingPrefabs[];
extern const size_t g_PlainsVillagePrefabsCount;
extern const size_t g_PlainsVillageStartingPrefabsCount;

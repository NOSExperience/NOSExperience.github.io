
// SandVillagePrefabs.h

// Declares the prefabs in the group SandVillage

#include "../Prefab.h"





extern const cPrefab::sDef g_SandVillagePrefabs[];
extern const cPrefab::sDef g_SandVillageStartingPrefabs[];
extern const size_t g_SandVillagePrefabsCount;
extern const size_t g_SandVillageStartingPrefabsCount;

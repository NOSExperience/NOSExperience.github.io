
// RainbowRoadPrefabs.h

// Declares the prefabs in the group RainbowRoad

#include "../Prefab.h"





extern const cPrefab::sDef g_RainbowRoadPrefabs[];
extern const cPrefab::sDef g_RainbowRoadStartingPrefabs[];
extern const size_t g_RainbowRoadPrefabsCount;
extern const size_t g_RainbowRoadStartingPrefabsCount;


// SandFlatRoofVillagePrefabs.h

// Declares the prefabs in the group SandFlatRoofVillage

#include "../Prefab.h"





extern const cPrefab::sDef g_SandFlatRoofVillagePrefabs[];
extern const cPrefab::sDef g_SandFlatRoofVillageStartingPrefabs[];
extern const size_t g_SandFlatRoofVillagePrefabsCount;
extern const size_t g_SandFlatRoofVillageStartingPrefabsCount;


// UnderwaterBasePrefabs.h

// Declares the prefabs in the group UnderwaterBase

#include "../Prefab.h"





extern const cPrefab::sDef g_UnderwaterBasePrefabs[];
extern const cPrefab::sDef g_UnderwaterBaseStartingPrefabs[];
extern const size_t g_UnderwaterBasePrefabsCount;
extern const size_t g_UnderwaterBaseStartingPrefabsCount;

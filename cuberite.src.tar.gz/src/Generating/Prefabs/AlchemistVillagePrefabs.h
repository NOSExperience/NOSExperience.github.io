
// AlchemistVillagePrefabs.h

// Declares the prefabs in the group AlchemistVillage

#include "../Prefab.h"





extern const cPrefab::sDef g_AlchemistVillagePrefabs[];
extern const cPrefab::sDef g_AlchemistVillageStartingPrefabs[];
extern const size_t g_AlchemistVillagePrefabsCount;
extern const size_t g_AlchemistVillageStartingPrefabsCount;
